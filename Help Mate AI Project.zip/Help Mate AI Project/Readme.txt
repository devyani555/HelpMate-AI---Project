HELPMATE_AI Semantic Search System

OVERVIEW  
------------  
HELPMATE_AI is a cutting-edge semantic search solution that harnesses the power of the Retrieval-Augmented Generation (RAG) pipeline to efficiently fetch and rank documents. By employing sophisticated NLP techniques, it processes PDF content to provide precise answers to user queries.

KEY FEATURES  
----------------  
- Accurate document retrieval through semantic search with the RAG pipeline.
- Extraction and transformation of PDF text and tables into vector representations.
- Performance enhancement via an integrated caching mechanism.
- Scalable vector storage with Chroma DB for expansive search capabilities.

SETUP INSTRUCTIONS  
-----------------------  
1. Clone the repository:  
   `
2. Enter the project directory:  
   `
3. Install the necessary dependencies:  
   `

DOCUMENTATION  
-----------------  
- Summary:   
- Visuals:   
- Detailed Overview:

HOW TO USE  
--------------  
- Run the code in `main.ipynb` using Jupyter Notebook.
- Follow the notebook's guidelines for document processing and conducting semantic searches.

CONFIGURATION DETAILS  
--------------------------  
- Configure environment variables for database and API integrations.
- Adjust cache settings in the ChromaDB configuration file as needed.

GET IN TOUCH  
----------------  
Project Repository:

THANKS TO  
--------------  
- OpenAI for providing language model APIs.
- Hugging Face for their transformer models.
- The creators of pdfplumber, tiktoken, and ChromaDB libraries.

Be sure to follow the installation and setup instructions closely and refer to the scripts for detailed information on their functionalities.